// when we click registration button
$('#registration').click(() => {
    store();
})

// when we click login
$('#signin').click(() => {
    let email = $('#userName').val();
    let password = $('#userPw').val();
    login(email, password);
});

function store() {
    let email = document.getElementById('email');
    let password = document.getElementById('pw');
    let fullname = document.getElementById('fullname');
    let image = document.getElementById('image');
    let country = document.getElementById('country');
    let date = document.getElementById('date');
    let time = document.getElementById('time');
    let gender = document.querySelector('input[name="gender"]:checked');
    let color = document.getElementById('color');

    if (email.value.length == 0) {
        alert('Please fill in email');

    } else if (password.value.length == 0) {
        alert('Please fill in password');

    } else if (email.value.length == 0 && password.value.length == 0) {
        alert('Please fill in email and password');

    } else {
        registratration(email.value, password.value, fullname.value, image.value, country.value, date.value, time.value, gender.value, color.value);
    }
}

//when registrate successfully
function successRegistare() {
    swal({
        title: `${$('#fullname').val()}`,
        text: `You registered successfully `,
        icon: "success",
    });
}

//when login successfully
function successLogin() {
    swal({
        title: `${$('#userName').val()}`,
        text: `You are logged in!`,
        icon: "success",
    });
    document.querySelector('.container h1 span').innerHTML = localStorage.getItem('fullname');
}

//!Insert Data in DB -> Registration
function registratration(email, password, fullname, image, country, date, time, gender, color) {
    $.ajax({
        url: 'registration.php',
        type: 'POST',
        data: {
            email : email,
            password : password,
            fullname : fullname,
            image : image,
            country : country,
            date : date,
            time : time,
            gender : gender,
            color : color
        },
        success: function (result) {
            if(result.replace(/\s/g, '') === 'Success!'){ 
                successRegistare();
                document.querySelector('#registrate').classList.add('hide');
                document.querySelector('#login').classList.remove('hide');
            }else{
                alert(result)
            }
        },
        error: function () {
            alert('Error from Server!');
        }
    });
}

//Select Data from DB -> Login 
function login(email, pass) {
    $.ajax({
        url: 'login.php',
        type: 'POST',
        data: { email: email, password: pass },
        success: function (result) {
            if (result == "Success!") {
                successLogin();
                setTimeout(() => {
                    document.querySelector('#login').classList.add('hide');
                    document.querySelector('.container').classList.remove('hide');
                    document.querySelector('.container h1 span').innerHTML = email;
                }, 1000)
            } else {
                alert('Fatal Error!')
            }
        },
        error: function () {
            alert('Fatal Error!')
        }
    });
}
