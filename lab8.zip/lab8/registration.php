<?php
// //Create connection
$conn = mysqli_connect("127.0.0.1", "root", "", "test");
//Check Connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if($conn){
    $email = $_POST['email']; // username
    $password = $_POST['password']; // email 
    $fullname = $_POST['fullname']; // password
    $image = $_POST['image']; //date of birth
    $country = $_POST['country']; //date of birth
    $date = $_POST['date']; //date of birth
    $time = $_POST['time']; //date of birth
    $gender = $_POST['gender']; //date of birth
    $color = $_POST['color']; //date of birth

    //!INSERTION TO DB;
    $sqlInsert = "INSERT INTO users(email, password, fullname, image, country, birthdate, birthtime, gender, color )
                  VALUES ('$email', '$password', '$fullname', '$image', '$country', '$date', '$time', '$gender', '$color')";
    $result = mysqli_query($conn, $sqlInsert);
    if ($result) {
        echo "Success!";
    }else{
        echo "Error!";
    }
}



?>