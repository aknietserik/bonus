<?php
//Create connection
$conn = mysqli_connect("127.0.0.1", "root", "", "test");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if($conn){ 
  $email = $_POST['email'];
  $password = $_POST['password'];

  //!SELECTION FROM DATABASE
  $sqlSelect = "SELECT * FROM users WHERE email = " . " '$email' " . " AND password = " . " '$password' " . 'limit 1';
  $result = mysqli_query($conn, $sqlSelect);

  if(mysqli_num_rows($result) == 1){
      echo "Success!";
  }
  else{
      echo "Wrong data!";
  }

}


?>